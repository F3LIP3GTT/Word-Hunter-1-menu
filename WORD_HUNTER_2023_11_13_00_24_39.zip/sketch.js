let botaoInfo;
let nn;
let tp = 0;
let video;
let botaoPlay;
let botaoCredito; // Novo botão
let botaoX;
let botaoC;
let botaoD;
let botaoY;
let larguraBotao;
let botaoWinfo;
let alturaBotao;
let tela = 0;
let telaInfo;
let telaCredito; // Nova tela de créditos
let contadorCliquesEnter = 0;

function preload() {
  botaoPlay = loadImage("st.png");
  botaoInfo = loadImage("!.png");
  botaoCredito = loadImage("cred2.png");
  telaInfo = loadImage("infotela.gif");
  telaCredito = loadImage("credetela.gif"); // Nova tela de créditos
}

function setup() {
  createCanvas(800, 500);
  video = createVideo("fg.mp4");
  video.hide();
  video.loop();
  frameRate(30);

  botaoPlay.resize(117, 117);
  botaoInfo.resize(35, 36);
  botaoCredito.resize(34, 34);
  telaInfo.resize(width, height);
  telaCredito.resize(width, height); // Redimensiona a tela de créditos para o tamanho da tela

  // Variáveis do botão Play
  botaoX = width / 2 - botaoPlay.width / 1.7;
  botaoY = height - botaoPlay.height / 1;
  larguraBotao = botaoPlay.width;
  alturaBotao = botaoPlay.height;

  // Variáveis do botão Info
  botaoD = 760;
  botaoC = 10;
  botaoWinfo = botaoInfo.width;

  // Variáveis do botão Credito
  creditoBotaoX = 760;
  creditoBotaoY = 60;
  creditoBotaoLargura = botaoCredito.width;
  creditoBotaoAltura = botaoCredito.height;
}

function draw() {
  if (tela == 0) {
    noTint();
    image(video, 0, 0, width, height);
    tint(255, tp);
    if (tp < 160) {
      tp = tp + 1;
    }
    image(botaoPlay, botaoX, botaoY);
    image(botaoInfo, botaoD, botaoC);
    image(botaoCredito, creditoBotaoX, creditoBotaoY); // Novo botão
  }

  if (tela == 1) {
    background(0);
  }

  if (tela == 2) {
    image(telaInfo, 0, 0);
    textAlign(CENTER, TOP);
    textSize(24);
    fill(255);
    text("🚀Bem-vindo ao Word Hunter!🚀", width / 2, 50);

    textSize(16);
    text(
      "Word Hunter é mais do que apenas um jogo; é uma experiência educativa que desafia suas habilidades de digitação enquanto explora o espaço. Inspirado no clássico jogo dos asteroides, esta versão única coloca você no comando de uma nave espacial, onde sua missão é destruir asteroides digitando as palavras que estão dentro deles.Prepare-se para a emoção de aprimorar sua velocidade de digitação enquanto defende o universo. Cada palavra digitada corretamente resulta na explosão de um asteroide, trazendo uma nova dimensão ao aprendizado e tornando a jornada pelo espaço ainda mais empolgante.Desafie-se a digitar cada palavra com precisão e rapidez, pois sua habilidade é crucial para a sobrevivência no cosmos. Word Hunter é mais que um jogo; é uma jornada educativa que transforma a aprendizagem em uma aventura intergaláctica. Vamos explorar o espaço enquanto aprimoramos nossas habilidades de digitação! 🚀💻.",
      width / 9,
      100,
      600,
      400
    );
  }

  if (tela == 3) {
    // Tela de créditos
    image(telaCredito, 0, 0);
    textAlign(CENTER, TOP);
    textSize(24);
    fill(255);
    text("🌟 Créditos do Word Hunter 🌟", width / 2, 50);

    textSize(16);
    text("Mestre das Linhas de Código 🚀:", width / 2, 100);
    text("Felipe Gabriel Tavares Teixeira 🔱", width / 2, 130);
    text("📧 E-mail: Felipe.tavares.123@ufrn.edu.br", width / 2, 160);

    text("Sábio nas Estrelas e Guia na Programação 🌌:", width / 2, 250);
    text(
      "Orientador Estelar: Orivaldo Vieira De Santana Junior",
      width / 2,
      280
    );
    text(
      "Uma criação brilhante de Felipe, onde cada linha de código é uma constelação de aprendizado! 🌠✨",
      width / 2,
      340
    );
    text(
      "Que o Word Hunter continue encantando jogadores em sua jornada pelo cosmos digital! 🚀🔮",
      width / 2,
      400
    );
  }
}

function mousePressed() {
  if (
    tela == 0 &&
    mouseX >= botaoX &&
    mouseX <= botaoX + larguraBotao &&
    mouseY >= botaoY &&
    mouseY <= botaoY + alturaBotao
  ) {
    tela = 1;
  }

  if (
    tela == 0 &&
    mouseX >= botaoD &&
    mouseX <= botaoD + botaoWinfo &&
    mouseY >= botaoC &&
    mouseY <= 45
  ) {
    tela = 2;
  }

  if (
    tela == 0 &&
    mouseX >= creditoBotaoX &&
    mouseX <= creditoBotaoX + creditoBotaoLargura &&
    mouseY >= creditoBotaoY &&
    mouseY <= creditoBotaoY + creditoBotaoAltura
  ) {
    tela = 3; // Botão creditoBotao mostra a tela de créditos
  }

  if (
    tela == 0 &&
    mouseX >= botaoD &&
    mouseX <= botaoD + botaoWinfo &&
    mouseY >= botaoC + botaoInfo.height + 10 &&
    mouseY <= botaoC + botaoInfo.height + 10 + alturaBotao
  ) {
    tela = 0; // Botão botaoInfo volta ao menu principal
  }
}

function keyPressed() {
  if (keyCode === ENTER) {
    contadorCliquesEnter++;
    if (contadorCliquesEnter >= 3) {
      tela = 0;
      contadorCliquesEnter = 0;
    }
  }
}
